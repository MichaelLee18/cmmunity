create index "flyway_schema_history_s_idx"
    on "flyway_schema_history" ("success");

